
from transformers import BertTokenizer, BertForSequenceClassification
import torch
import numpy as np
from flask import Flask, jsonify, request
from flask_cors import CORS, cross_origin

def softmax(x):
    """Compute softmax values for each sets of scores in x."""
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum(axis=0)

def get_prediction(sentence):
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model = BertForSequenceClassification.from_pretrained('bert-base-uncased', return_dict=True)
    inputs = tokenizer(sentence, return_tensors="pt")
    labels = torch.tensor([1]).unsqueeze(0) 
    outputs = softmax(model(**inputs, labels=labels).logits[0].detach().numpy())
    prediction = np.argmax(outputs)
    return prediction

application = Flask(__name__)
CORS(application)
application.config['CORS_HEADERS'] = 'Content-Type'

@application.route('/sentence', methods=['GET'])
def get_sentence():
    if request.method == 'GET':
        response = jsonify({
            'sentence': "123"
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

@application.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        sentence = request.form["sentence"]
        prediction = int(get_prediction(sentence))
        response = jsonify({
            'prediction': prediction
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response 

if __name__ == '__main__':
  application.run()